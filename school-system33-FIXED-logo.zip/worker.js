const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS teachers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    subject TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS classes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE COLLATE NOCASE,
    teacher_id TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL
  )`,
  `CREATE TABLE IF NOT EXISTS students (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    iin TEXT NOT NULL UNIQUE,
    birth_date TEXT NOT NULL DEFAULT '',
    class_id TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'Активный',
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL
  )`,
  `CREATE INDEX IF NOT EXISTS idx_students_iin ON students(iin)`,
  `CREATE INDEX IF NOT EXISTS idx_students_class_id ON students(class_id)`,
];

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: JSON_HEADERS,
  });
}

function error(message, status = 400) {
  return json({ ok: false, error: message }, status);
}

function id() {
  return crypto.randomUUID();
}

function clean(value) {
  return value == null ? "" : String(value).trim();
}

function normalizeIIN(value) {
  return clean(value).replace(/\s+/g, "");
}

function normalizeStatus(value) {
  const v = clean(value).toLowerCase();
  if (v === "выбыл") return "Выбыл";
  if (v === "переведён" || v === "переведен") return "Переведён";
  return "Активный";
}

function mapTeacher(row) {
  return { id: row.id, name: row.name, subject: row.subject || "" };
}

function mapClass(row) {
  return { id: row.id, name: row.name, teacherId: row.teacher_id || "" };
}

function mapStudent(row) {
  return {
    id: row.id,
    name: row.name,
    iin: row.iin,
    birthDate: row.birth_date || "",
    classId: row.class_id || "",
    status: row.status || "Активный",
    note: row.note || "",
  };
}

async function ensureSchema(db) {
  for (const statement of SCHEMA) await db.prepare(statement).run();
}

async function getState(db) {
  const [students, classes, teachers] = await Promise.all([
    db.prepare("SELECT id,name,iin,birth_date,class_id,status,note FROM students ORDER BY name COLLATE NOCASE").all(),
    db.prepare("SELECT id,name,teacher_id FROM classes ORDER BY name COLLATE NOCASE").all(),
    db.prepare("SELECT id,name,subject FROM teachers ORDER BY name COLLATE NOCASE").all(),
  ]);

  return {
    students: students.results.map(mapStudent),
    classes: classes.results.map(mapClass),
    teachers: teachers.results.map(mapTeacher),
  };
}

function isConstraintError(err) {
  return /unique|constraint|UNIQUE/i.test(String(err?.message || err));
}

async function parseBody(request) {
  try {
    return await request.json();
  } catch {
    throw new Error("Некорректный JSON-запрос");
  }
}

async function handleApi(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  if (method === "OPTIONS") {
    return new Response(null, { status: 204, headers: { "access-control-allow-origin": "*", "access-control-allow-methods": "GET,POST,PUT,DELETE,OPTIONS", "access-control-allow-headers": "content-type" } });
  }

  if (!env.DB) return error("D1 binding DB не подключён к Worker.", 500);
  await ensureSchema(env.DB);

  if (path === "/api/health" && method === "GET") {
    return json({ ok: true, database: "D1" });
  }

  if (path === "/api/state" && method === "GET") {
    return json({ ok: true, ...await getState(env.DB) });
  }

  if (path === "/api/students" && method === "POST") {
    const body = await parseBody(request);
    const name = clean(body.name);
    const iin = normalizeIIN(body.iin);
    const birthDate = clean(body.birthDate);
    const classId = clean(body.classId);
    const status = normalizeStatus(body.status);
    const note = clean(body.note);

    if (!name || !/^\d{12}$/.test(iin) || !classId) return error("Заполните ФИО, корректный ИИН из 12 цифр и класс.");
    try {
      const newId = id();
      await env.DB.prepare(`INSERT INTO students (id,name,iin,birth_date,class_id,status,note) VALUES (?,?,?,?,?,?,?)`)
        .bind(newId, name, iin, birthDate, classId, status, note).run();
      return json({ ok: true, id: newId });
    } catch (err) {
      return error(isConstraintError(err) ? "Ученик с таким ИИН уже есть в базе." : "Не удалось сохранить ученика.", isConstraintError(err) ? 409 : 500);
    }
  }

  if (path.startsWith("/api/students/") && (method === "PUT" || method === "DELETE")) {
    const studentId = decodeURIComponent(path.slice("/api/students/".length));
    if (!studentId) return error("Не указан ID ученика.");

    if (method === "DELETE") {
      await env.DB.prepare("DELETE FROM students WHERE id=?").bind(studentId).run();
      return json({ ok: true });
    }

    const body = await parseBody(request);
    const name = clean(body.name);
    const iin = normalizeIIN(body.iin);
    const birthDate = clean(body.birthDate);
    const classId = clean(body.classId);
    const status = normalizeStatus(body.status);
    const note = clean(body.note);
    if (!name || !/^\d{12}$/.test(iin) || !classId) return error("Заполните ФИО, корректный ИИН из 12 цифр и класс.");

    try {
      await env.DB.prepare(`UPDATE students SET name=?,iin=?,birth_date=?,class_id=?,status=?,note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
        .bind(name, iin, birthDate, classId, status, note, studentId).run();
      return json({ ok: true });
    } catch (err) {
      return error(isConstraintError(err) ? "Другой ученик уже использует этот ИИН." : "Не удалось изменить ученика.", isConstraintError(err) ? 409 : 500);
    }
  }

  if (path === "/api/classes" && method === "POST") {
    const body = await parseBody(request);
    const name = clean(body.name);
    const teacherId = clean(body.teacherId);
    if (!name) return error("Введите название класса.");
    try {
      const newId = id();
      await env.DB.prepare("INSERT INTO classes (id,name,teacher_id) VALUES (?,?,?)").bind(newId, name, teacherId).run();
      return json({ ok: true, id: newId });
    } catch (err) {
      return error(isConstraintError(err) ? "Такой класс уже существует." : "Не удалось сохранить класс.", isConstraintError(err) ? 409 : 500);
    }
  }

  if (path.startsWith("/api/classes/") && (method === "PUT" || method === "DELETE")) {
    const classId = decodeURIComponent(path.slice("/api/classes/".length));
    if (method === "DELETE") {
      await env.DB.batch([
        env.DB.prepare("UPDATE students SET class_id='' WHERE class_id=?").bind(classId),
        env.DB.prepare("DELETE FROM classes WHERE id=?").bind(classId),
      ]);
      return json({ ok: true });
    }
    const body = await parseBody(request);
    const name = clean(body.name);
    const teacherId = clean(body.teacherId);
    if (!name) return error("Введите название класса.");
    try {
      await env.DB.prepare("UPDATE classes SET name=?,teacher_id=? WHERE id=?").bind(name, teacherId, classId).run();
      return json({ ok: true });
    } catch (err) {
      return error(isConstraintError(err) ? "Такой класс уже существует." : "Не удалось изменить класс.", isConstraintError(err) ? 409 : 500);
    }
  }

  if (path === "/api/teachers" && method === "POST") {
    const body = await parseBody(request);
    const name = clean(body.name);
    const subject = clean(body.subject);
    if (!name) return error("Введите ФИО преподавателя.");
    const newId = id();
    await env.DB.prepare("INSERT INTO teachers (id,name,subject) VALUES (?,?,?)").bind(newId, name, subject).run();
    return json({ ok: true, id: newId });
  }

  if (path.startsWith("/api/teachers/") && (method === "PUT" || method === "DELETE")) {
    const teacherId = decodeURIComponent(path.slice("/api/teachers/".length));
    if (method === "DELETE") {
      await env.DB.batch([
        env.DB.prepare("UPDATE classes SET teacher_id='' WHERE teacher_id=?").bind(teacherId),
        env.DB.prepare("DELETE FROM teachers WHERE id=?").bind(teacherId),
      ]);
      return json({ ok: true });
    }
    const body = await parseBody(request);
    const name = clean(body.name);
    const subject = clean(body.subject);
    if (!name) return error("Введите ФИО преподавателя.");
    await env.DB.prepare("UPDATE teachers SET name=?,subject=? WHERE id=?").bind(name, subject, teacherId).run();
    return json({ ok: true });
  }

  if (path === "/api/backup/import" && method === "POST") {
    const body = await parseBody(request);
    if (!body || !Array.isArray(body.students) || !Array.isArray(body.classes) || !Array.isArray(body.teachers)) {
      return error("Неверный формат резервной копии.");
    }

    const statements = [
      env.DB.prepare("DELETE FROM students"),
      env.DB.prepare("DELETE FROM classes"),
      env.DB.prepare("DELETE FROM teachers"),
    ];

    for (const t of body.teachers) {
      const tid = clean(t.id) || id();
      const name = clean(t.name);
      if (name) statements.push(env.DB.prepare("INSERT INTO teachers (id,name,subject) VALUES (?,?,?)").bind(tid, name, clean(t.subject)));
    }
    for (const c of body.classes) {
      const cid = clean(c.id) || id();
      const name = clean(c.name);
      if (name) statements.push(env.DB.prepare("INSERT INTO classes (id,name,teacher_id) VALUES (?,?,?)").bind(cid, name, clean(c.teacherId)));
    }
    for (const s of body.students) {
      const sid = clean(s.id) || id();
      const name = clean(s.name);
      const iin = normalizeIIN(s.iin);
      if (name && /^\d{12}$/.test(iin)) {
        statements.push(env.DB.prepare("INSERT INTO students (id,name,iin,birth_date,class_id,status,note) VALUES (?,?,?,?,?,?,?)")
          .bind(sid, name, iin, clean(s.birthDate), clean(s.classId), normalizeStatus(s.status), clean(s.note)));
      }
    }

    try {
      for (let i = 0; i < statements.length; i += 100) await env.DB.batch(statements.slice(i, i + 100));
      return json({ ok: true });
    } catch (err) {
      return error("Не удалось импортировать резервную копию. Проверьте уникальность ИИН и классов.", 400);
    }
  }

  if (path === "/api/database/clear" && method === "POST") {
    const body = await parseBody(request);
    const expected = clean(env.CLEAR_DB_PASSWORD);
    if (!expected) return error("На Worker не задан секрет CLEAR_DB_PASSWORD.", 500);
    if (clean(body.password) !== expected) return error("Неверный пароль.", 403);

    await env.DB.batch([
      env.DB.prepare("DELETE FROM students"),
      env.DB.prepare("DELETE FROM classes"),
      env.DB.prepare("DELETE FROM teachers"),
    ]);
    return json({ ok: true });
  }

  return error("API endpoint не найден.", 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      try {
        return await handleApi(request, env);
      } catch (err) {
        console.error(err);
        return error("Внутренняя ошибка сервера.", 500);
      }
    }
    return env.ASSETS.fetch(request);
  },
};
