let db = { students: [], classes: [], teachers: [] };
let loading = false;

function apiErrorMessage(error) {
    return error?.message || "Ошибка сервера";
}

async function api(path, options = {}) {
    const response = await fetch(path, {
        ...options,
        headers: { "Content-Type": "application/json", ...(options.headers || {}) }
    });
    let data = null;
    try { data = await response.json(); } catch (_) {}
    if (!response.ok || data?.ok === false) {
        throw new Error(data?.error || `HTTP ${response.status}`);
    }
    return data;
}

async function loadDatabase() {
    loading = true;
    try {
        const data = await api("/api/state");
        db = {
            students: Array.isArray(data.students) ? data.students : [],
            classes: Array.isArray(data.classes) ? data.classes : [],
            teachers: Array.isArray(data.teachers) ? data.teachers : []
        };
        renderAll();
    } catch (error) {
        console.error(error);
        showToast(`Не удалось подключиться к D1: ${apiErrorMessage(error)}`, "error");
    } finally {
        loading = false;
    }
}

function setupNavigation() {
    document.querySelectorAll(".nav-item").forEach(button => {
        button.addEventListener("click", () => showPage(button.dataset.page));
    });
}

function showPage(pageId) {
    document.querySelectorAll(".page").forEach(page => page.classList.remove("active"));
    document.querySelectorAll(".nav-item").forEach(item => item.classList.remove("active"));

    document.getElementById(pageId)?.classList.add("active");
    document.querySelector(`.nav-item[data-page="${pageId}"]`)?.classList.add("active");

    const titles = {
        dashboard: "Главная",
        students: "Ученики",
        classes: "Классы",
        teachers: "Преподаватели",
        search: "Поиск по ИИН",
        backup: "Резервная копия"
    };
    document.getElementById("pageTitle").textContent = titles[pageId] || "Школа №33";

    if (pageId === "students") populateStudentFilters();
    if (pageId === "backup") populateExcelClassSelect();
}

function renderAll() {
    updateStatistics();
    renderDashboard();
    renderStudents();
    renderClasses();
    renderTeachers();
    populateStudentClassSelect();
    populateStudentFilters();
    populateTeacherSelect();
    populateExcelClassSelect();
}

function updateStatistics() {
    document.getElementById("statStudents").textContent = db.students.length;
    document.getElementById("statClasses").textContent = db.classes.length;
    document.getElementById("statTeachers").textContent = db.teachers.length;
    document.getElementById("statActive").textContent = db.students.filter(s => normalizeStatus(s.status) === "Активный").length;
}

function renderDashboard() {
    const tbody = document.getElementById("recentStudents");
    const list = db.students.slice().sort((a, b) => (b.id || "").localeCompare(a.id || "")).slice(0, 8);
    tbody.innerHTML = list.length ? list.map(s => `
        <tr>
            <td>${escapeHTML(s.name)}</td>
            <td>${escapeHTML(s.iin)}</td>
            <td>${escapeHTML(getClassName(s.classId))}</td>
            <td>${statusBadge(s.status)}</td>
        </tr>`).join("") : `<tr><td colspan="4" class="empty">Записей пока нет</td></tr>`;
}

function openClassModal(id = null) {
    populateTeacherSelect();
    document.getElementById("classId").value = id || "";
    document.getElementById("classModalTitle").textContent = id ? "Изменить класс" : "Добавить класс";
    const item = id ? getClass(id) : null;
    document.getElementById("className").value = item?.name || "";
    document.getElementById("classTeacher").value = item?.teacherId || "";
    openModal("classModal");
}

async function saveClass(event) {
    event.preventDefault();
    const id = document.getElementById("classId").value;
    const name = document.getElementById("className").value.trim();
    const teacherId = document.getElementById("classTeacher").value;
    if (!name) return showToast("Введите название класса", "error");

    try {
        await api(id ? `/api/classes/${encodeURIComponent(id)}` : "/api/classes", {
            method: id ? "PUT" : "POST",
            body: JSON.stringify({ name, teacherId })
        });
        closeModal("classModal");
        await loadDatabase();
        showToast("Класс сохранён", "success");
    } catch (error) { showToast(apiErrorMessage(error), "error"); }
}

async function deleteClass(id) {
    const item = getClass(id);
    if (!item) return;
    const count = db.students.filter(s => s.classId === id).length;
    const message = count ? `В классе "${item.name}" находятся ${count} ученик(ов). Удалить класс всё равно?` : `Удалить класс "${item.name}"?`;
    if (!confirm(message)) return;
    try {
        await api(`/api/classes/${encodeURIComponent(id)}`, { method: "DELETE" });
        await loadDatabase();
        showToast("Класс удалён", "success");
    } catch (error) { showToast(apiErrorMessage(error), "error"); }
}

function renderClasses() {
    const container = document.getElementById("classesGrid");
    if (!db.classes.length) {
        container.innerHTML = `<div class="card empty">Классы ещё не добавлены</div>`;
        return;
    }
    container.innerHTML = db.classes.map(c => {
        const teacher = getTeacher(c.teacherId);
        const count = db.students.filter(s => s.classId === c.id).length;
        return `<div class="class-card">
            <h3>${escapeHTML(c.name)}</h3>
            <div class="teacher">Классный руководитель: ${escapeHTML(teacher ? teacher.name : "не назначен")}</div>
            <div class="count">👨‍🎓 Учеников: <strong>${count}</strong></div>
            <div class="actions">
                <button class="btn btn-secondary" onclick="viewClassStudents('${escapeAttribute(c.id)}')">Список</button>
                <button class="btn btn-secondary" onclick="exportClassExcel('${escapeAttribute(c.id)}')">Excel</button>
                <button class="icon-btn" onclick="openClassModal('${escapeAttribute(c.id)}')">✏️</button>
                <button class="icon-btn danger" onclick="deleteClass('${escapeAttribute(c.id)}')">🗑</button>
            </div>
        </div>`;
    }).join("");
}

function viewClassStudents(classId) {
    const item = getClass(classId);
    if (!item) return;
    showPage("students");
    const filter = document.getElementById("studentClassFilter");
    if (filter) { filter.value = classId; renderStudents(); }
}

function openTeacherModal(id = null) {
    document.getElementById("teacherId").value = id || "";
    document.getElementById("teacherModalTitle").textContent = id ? "Изменить преподавателя" : "Добавить преподавателя";
    const item = id ? getTeacher(id) : null;
    document.getElementById("teacherName").value = item?.name || "";
    document.getElementById("teacherSubject").value = item?.subject || "";
    openModal("teacherModal");
}

async function saveTeacher(event) {
    event.preventDefault();
    const id = document.getElementById("teacherId").value;
    const name = document.getElementById("teacherName").value.trim();
    const subject = document.getElementById("teacherSubject").value.trim();
    if (!name) return showToast("Введите ФИО преподавателя", "error");
    try {
        await api(id ? `/api/teachers/${encodeURIComponent(id)}` : "/api/teachers", {
            method: id ? "PUT" : "POST", body: JSON.stringify({ name, subject })
        });
        closeModal("teacherModal");
        await loadDatabase();
        showToast("Преподаватель сохранён", "success");
    } catch (error) { showToast(apiErrorMessage(error), "error"); }
}

async function deleteTeacher(id) {
    const item = getTeacher(id);
    if (!item || !confirm(`Удалить преподавателя "${item.name}"?`)) return;
    try {
        await api(`/api/teachers/${encodeURIComponent(id)}`, { method: "DELETE" });
        await loadDatabase();
        showToast("Преподаватель удалён", "success");
    } catch (error) { showToast(apiErrorMessage(error), "error"); }
}

function renderTeachers() {
    const tbody = document.getElementById("teachersTable");
    if (!db.teachers.length) {
        tbody.innerHTML = `<tr><td colspan="5" class="empty">Преподаватели ещё не добавлены</td></tr>`;
        return;
    }
    tbody.innerHTML = db.teachers.map((t, index) => {
        const classCount = db.classes.filter(c => c.teacherId === t.id).length;
        return `<tr>
            <td>${index + 1}</td><td>${escapeHTML(t.name)}</td><td>${escapeHTML(t.subject || "—")}</td><td>${classCount}</td>
            <td class="actions"><button class="icon-btn" onclick="openTeacherModal('${escapeAttribute(t.id)}')">✏️</button><button class="icon-btn danger" onclick="deleteTeacher('${escapeAttribute(t.id)}')">🗑</button></td>
        </tr>`;
    }).join("");
}

function openStudentModal(id = null) {
    populateStudentClassSelect();
    document.getElementById("studentId").value = id || "";
    document.getElementById("studentModalTitle").textContent = id ? "Изменить ученика" : "Добавить ученика";
    const item = id ? db.students.find(s => s.id === id) : null;
    document.getElementById("studentName").value = item?.name || "";
    document.getElementById("studentIIN").value = item?.iin || "";
    document.getElementById("studentBirthDate").value = item?.birthDate || "";
    document.getElementById("studentClass").value = item?.classId || "";
    document.getElementById("studentStatus").value = normalizeStatus(item?.status);
    document.getElementById("studentNote").value = item?.note || "";
    openModal("studentModal");
}

async function saveStudent(event) {
    event.preventDefault();
    const id = document.getElementById("studentId").value;
    const name = document.getElementById("studentName").value.trim();
    const iin = normalizeIIN(document.getElementById("studentIIN").value);
    const birthDate = document.getElementById("studentBirthDate").value;
    const classId = document.getElementById("studentClass").value;
    const status = normalizeStatus(document.getElementById("studentStatus").value);
    const note = document.getElementById("studentNote").value.trim();
    if (!name || !classId) return showToast("Заполните обязательные поля", "error");
    if (!/^\d{12}$/.test(iin)) return showToast("ИИН должен содержать ровно 12 цифр", "error");
    try {
        await api(id ? `/api/students/${encodeURIComponent(id)}` : "/api/students", {
            method: id ? "PUT" : "POST", body: JSON.stringify({ name, iin, birthDate, classId, status, note })
        });
        closeModal("studentModal");
        await loadDatabase();
        showToast("Ученик сохранён", "success");
    } catch (error) { showToast(apiErrorMessage(error), "error"); }
}

async function deleteStudent(id) {
    const item = db.students.find(s => s.id === id);
    if (!item || !confirm(`Удалить ученика "${item.name}"?`)) return;
    try {
        await api(`/api/students/${encodeURIComponent(id)}`, { method: "DELETE" });
        await loadDatabase();
        showToast("Ученик удалён", "success");
    } catch (error) { showToast(apiErrorMessage(error), "error"); }
}

function renderStudents() {
    const tbody = document.getElementById("studentsTable");
    const query = (document.getElementById("studentFilter")?.value || "").trim().toLowerCase();
    const classFilter = document.getElementById("studentClassFilter")?.value || "";
    const statusFilter = document.getElementById("studentStatusFilter")?.value || "";
    const list = db.students.filter(s => {
        const matchesQuery = !query || String(s.name || "").toLowerCase().includes(query) || String(s.iin || "").includes(query);
        const matchesClass = !classFilter || s.classId === classFilter;
        const matchesStatus = !statusFilter || normalizeStatus(s.status) === statusFilter;
        return matchesQuery && matchesClass && matchesStatus;
    });
    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty">Ученики не найдены</td></tr>`;
        return;
    }
    tbody.innerHTML = list.map((s, index) => `<tr>
        <td>${index + 1}</td><td>${escapeHTML(s.name)}</td><td>${escapeHTML(s.iin)}</td><td>${formatDate(s.birthDate)}</td>
        <td>${escapeHTML(getClassName(s.classId))}</td><td>${statusBadge(s.status)}</td>
        <td class="actions"><button class="icon-btn" onclick="openStudentModal('${escapeAttribute(s.id)}')">✏️</button><button class="icon-btn danger" onclick="deleteStudent('${escapeAttribute(s.id)}')">🗑</button></td>
    </tr>`).join("");
}

function populateStudentClassSelect() {
    const select = document.getElementById("studentClass");
    if (!select) return;
    const current = select.value;
    select.innerHTML = `<option value="">Выберите класс</option>` + db.classes.map(c => `<option value="${escapeAttribute(c.id)}">${escapeHTML(c.name)}</option>`).join("");
    if (db.classes.some(c => c.id === current)) select.value = current;
}

function populateStudentFilters() {
    const select = document.getElementById("studentClassFilter");
    if (!select) return;
    const current = select.value;
    select.innerHTML = `<option value="">Все классы</option>` + db.classes.map(c => `<option value="${escapeAttribute(c.id)}">${escapeHTML(c.name)}</option>`).join("");
    if (db.classes.some(c => c.id === current)) select.value = current;
}

function populateTeacherSelect() {
    const select = document.getElementById("classTeacher");
    if (!select) return;
    const current = select.value;
    select.innerHTML = `<option value="">Не назначен</option>` + db.teachers.map(t => `<option value="${escapeAttribute(t.id)}">${escapeHTML(t.name)}</option>`).join("");
    if (db.teachers.some(t => t.id === current)) select.value = current;
}

async function searchByIIN() {
    const iin = normalizeIIN(document.getElementById("iinSearchInput").value);
    const container = document.getElementById("searchResult");
    if (!/^\d{12}$/.test(iin)) {
        container.innerHTML = `<div class="search-result"><strong>Введите корректный ИИН из 12 цифр.</strong></div>`;
        return;
    }
    const student = db.students.find(s => s.iin === iin);
    if (!student) {
        container.innerHTML = `<div class="search-result"><strong>Ученик не найден.</strong><p>ИИН ${escapeHTML(iin)} отсутствует в базе.</p></div>`;
        return;
    }
    const cls = getClass(student.classId);
    const teacher = cls ? getTeacher(cls.teacherId) : null;
    container.innerHTML = `<div class="search-result">
        <h3>${escapeHTML(student.name)}</h3><p><strong>ИИН:</strong> ${escapeHTML(student.iin)}</p>
        <p><strong>Дата рождения:</strong> ${formatDate(student.birthDate)}</p><p><strong>Класс:</strong> ${escapeHTML(getClassName(student.classId))}</p>
        <p><strong>Классный руководитель:</strong> ${escapeHTML(teacher ? teacher.name : "не назначен")}</p>
        <p><strong>Статус:</strong> ${statusBadge(student.status)}</p><p><strong>Примечание:</strong> ${escapeHTML(student.note || "—")}</p>
    </div>`;
}

function exportData() {
    downloadBlob(JSON.stringify(db, null, 2), `Резервная_копия_${getDateForFile()}.json`, "application/json;charset=utf-8");
    showToast("JSON-файл скачан", "success");
}

async function importData(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
        const imported = JSON.parse(await file.text());
        if (!imported || !Array.isArray(imported.students) || !Array.isArray(imported.classes) || !Array.isArray(imported.teachers)) throw new Error("Неверный формат");
        if (!confirm("Заменить текущую общую базу данными из JSON-файла?")) return;
        await api("/api/backup/import", { method: "POST", body: JSON.stringify(imported) });
        await loadDatabase();
        showToast("База восстановлена из JSON", "success");
    } catch (error) { showToast(`Ошибка импорта: ${apiErrorMessage(error)}`, "error"); }
    event.target.value = "";
}

function exportStudentsExcel() { exportExcelForStudents(db.students, "Ученики"); }
function exportExcelFromBackup() {
    const classId = document.getElementById("excelClassSelect").value;
    classId ? exportClassExcel(classId) : exportStudentsExcel();
}
function exportClassExcel(classId) {
    const item = getClass(classId);
    if (!item) return;
    exportExcelForStudents(db.students.filter(s => s.classId === classId), `Ученики_${sanitizeFileName(item.name)}`);
}
function exportExcelForStudents(students, filenameBase) {
    if (typeof XLSX === "undefined") return showToast("Excel-библиотека не загружена. Проверьте интернет-соединение.", "error");
    const rows = students.map((s, index) => {
        const cls = getClass(s.classId); const teacher = cls ? getTeacher(cls.teacherId) : null;
        return { "№": index + 1, "ФИО": s.name || "", "ИИН": s.iin || "", "Дата рождения": s.birthDate || "", "Класс": cls?.name || "", "Классный руководитель": teacher?.name || "", "Предмет": teacher?.subject || "", "Статус": normalizeStatus(s.status), "Примечание": s.note || "" };
    });
    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = [{wch:6},{wch:32},{wch:16},{wch:16},{wch:12},{wch:30},{wch:20},{wch:15},{wch:35}];
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Ученики");
    XLSX.writeFile(wb, `${filenameBase}_${getDateForFile()}.xlsx`);
    showToast("Excel-файл скачан", "success");
}

function importExcel(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (typeof XLSX === "undefined") { showToast("Excel-библиотека не загружена.", "error"); event.target.value = ""; return; }
    const reader = new FileReader();
    reader.onload = e => {
        try {
            const workbook = XLSX.read(new Uint8Array(e.target.result), { type: "array" });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
            if (!rows.length) throw new Error("Excel-файл пуст");
            processExcelRows(rows);
        } catch (error) { showToast(`Не удалось прочитать Excel: ${error.message}`, "error"); }
        event.target.value = "";
    };
    reader.readAsArrayBuffer(file);
}

async function processExcelRows(rows) {
    const imported = { students: [...db.students], classes: [...db.classes], teachers: [...db.teachers] };
    let added = 0, updated = 0, skipped = 0;
    for (const row of rows) {
        const name = getExcelValue(row, ["ФИО", "фио", "ФИО ученика", "Ученик"]).trim();
        const iin = normalizeIIN(getExcelValue(row, ["ИИН", "иин"]));
        const birthDate = getExcelValue(row, ["Дата рождения", "Дата Рождения", "Дата рождения ученика"]).trim();
        const className = getExcelValue(row, ["Класс", "класс"]).trim();
        const status = normalizeStatus(getExcelValue(row, ["Статус", "статус"]));
        const note = getExcelValue(row, ["Примечание", "примечание", "Примечания"]).trim();
        if (!name || !/^\d{12}$/.test(iin) || !className) { skipped++; continue; }
        let cls = imported.classes.find(c => c.name.trim().toLowerCase() === className.toLowerCase());
        if (!cls) { cls = { id: generateId(), name: className, teacherId: "" }; imported.classes.push(cls); }
        const existing = imported.students.find(s => s.iin === iin);
        if (existing) { Object.assign(existing, { name, iin, birthDate, classId: cls.id, status, note }); updated++; }
        else { imported.students.push({ id: generateId(), name, iin, birthDate, classId: cls.id, status, note }); added++; }
    }
    try {
        await api("/api/backup/import", { method: "POST", body: JSON.stringify(imported) });
        await loadDatabase();
        showToast(`Excel импортирован: добавлено ${added}, обновлено ${updated}, пропущено ${skipped}`, "success");
    } catch (error) { showToast(`Ошибка импорта Excel: ${apiErrorMessage(error)}`, "error"); }
}

function populateExcelClassSelect() {
    const select = document.getElementById("excelClassSelect");
    if (!select) return;
    const current = select.value;
    select.innerHTML = `<option value="">Все классы</option>` + db.classes.map(c => `<option value="${escapeAttribute(c.id)}">${escapeHTML(c.name)}</option>`).join("");
    if (db.classes.some(c => c.id === current)) select.value = current;
}

async function clearDatabase() {
    const password = prompt("Введите пароль администратора для очистки базы данных:");
    if (password === null) return;
    if (!confirm("⚠️ Будут удалены ВСЕ ученики, классы и преподаватели из общей D1-базы. Продолжить?")) return;
    try {
        await api("/api/database/clear", { method: "POST", body: JSON.stringify({ password }) });
        await loadDatabase();
        showToast("Общая база данных полностью очищена", "success");
    } catch (error) { showToast(apiErrorMessage(error), "error"); }
}

function getExcelValue(row, names) {
    for (const name of names) if (row[name] !== undefined && row[name] !== null) return String(row[name]);
    const keys = Object.keys(row);
    const found = keys.find(key => names.some(name => key.trim().toLowerCase() === name.trim().toLowerCase()));
    return found ? String(row[found]) : "";
}
function normalizeIIN(value) { return String(value ?? "").replace(/\s+/g, "").trim(); }
function normalizeStatus(status) { const s = String(status ?? "").trim().toLowerCase(); if (s === "выбыл") return "Выбыл"; if (s === "переведён" || s === "переведен") return "Переведён"; return "Активный"; }
function statusBadge(status) { const s = normalizeStatus(status); const cls = s === "Активный" ? "status-active" : s === "Выбыл" ? "status-inactive" : "status-transferred"; return `<span class="status-badge ${cls}">${escapeHTML(s)}</span>`; }
function getClass(id) { return db.classes.find(c => c.id === id); }
function getClassName(id) { return getClass(id)?.name || "—"; }
function getTeacher(id) { return db.teachers.find(t => t.id === id); }
function generateId() { return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`; }
function formatDate(value) { if (!value) return "—"; const parts = String(value).split("-"); return parts.length === 3 ? `${parts[2]}.${parts[1]}.${parts[0]}` : escapeHTML(value); }
function getDateForFile() { return new Date().toISOString().slice(0, 10); }
function sanitizeFileName(value) { return String(value || "file").replace(/[\\/:*?"<>|]/g, "_"); }
function escapeHTML(value) { return String(value ?? "").replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c])); }
function escapeAttribute(value) { return escapeHTML(value); }
function downloadBlob(content, filename, type) { const blob = new Blob([content], { type }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); }
function openModal(id) { document.getElementById(id)?.classList.add("open"); }
function closeModal(id) { document.getElementById(id)?.classList.remove("open"); }
function updateCurrentDate() { document.getElementById("currentDate").textContent = new Intl.DateTimeFormat("ru-RU", { dateStyle: "long" }).format(new Date()); }
function showToast(message, type = "") { const container = document.getElementById("toastContainer"); const toast = document.createElement("div"); toast.className = `toast ${type}`; toast.textContent = message; container.appendChild(toast); setTimeout(() => toast.remove(), 4200); }


// Explicit button wiring: works even when inline onclick handlers are restricted.
function bindStaticButtons() {
    document.getElementById("addStudentBtn")?.addEventListener("click", () => openStudentModal());
    document.getElementById("addClassBtn")?.addEventListener("click", () => openClassModal());
    document.getElementById("addTeacherBtn")?.addEventListener("click", () => openTeacherModal());

    document.querySelectorAll("[data-close-modal]").forEach(btn => {
        btn.addEventListener("click", () => closeModal(btn.dataset.closeModal));
    });
}

// Make public functions available for the existing action buttons in rendered tables/cards.
Object.assign(window, {
    openStudentModal, openClassModal, openTeacherModal,
    closeModal, saveStudent, saveClass, saveTeacher,
    deleteStudent, deleteClass, deleteTeacher,
    viewClassStudents, exportClassExcel
});

document.addEventListener("DOMContentLoaded", async () => {
    setupNavigation();
    bindStaticButtons();
    document.getElementById("studentForm")?.addEventListener("submit", saveStudent);
    document.getElementById("classForm")?.addEventListener("submit", saveClass);
    document.getElementById("teacherForm")?.addEventListener("submit", saveTeacher);
    document.querySelectorAll(".modal").forEach(modal => modal.addEventListener("click", e => { if (e.target === modal) modal.classList.remove("open"); }));
    updateCurrentDate();
    setInterval(updateCurrentDate, 60000);
    await loadDatabase();
});
